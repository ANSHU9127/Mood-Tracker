
// Toggle selected buttons
const buttons = document.querySelectorAll('#emotions button');
buttons.forEach(btn => {
    btn.addEventListener('click', () => btn.classList.toggle('selected'));
});

const submitBtn = document.getElementById('submit');
const ctx = document.getElementById('moodChart').getContext('2d');
let moodChart;

function renderChart() {
    const moods = JSON.parse(localStorage.getItem('moodData')) || [];
    const labels = moods.map(m => m.date);
    const data = moods.map(m => m.score);
    
    if(moodChart) moodChart.destroy();
    
    moodChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{ label: 'Mood Score', data: data, borderColor: 'green', fill: false, tension: 0.2 }]
        },
        options: { scales: { y: { min: 0, max: 100 } } }
    });
}

submitBtn.addEventListener('click', () => {
    const selected = document.querySelectorAll('#emotions button.selected');
    if(selected.length === 0) return alert("Select at least one emotion!");
    
    const scores = Array.from(selected).map(b => parseFloat(b.dataset.score));
    const dailyScore = scores.reduce((a,b) => a+b, 0)/scores.length;
    const normalized = 50 + dailyScore*25;

    const moods = JSON.parse(localStorage.getItem('moodData')) || [];
    moods.push({ date: new Date().toLocaleDateString(), score: normalized });
    localStorage.setItem('moodData', JSON.stringify(moods));

    // Clear selection
    selected.forEach(b => b.classList.remove('selected'));
    document.getElementById('notes').value = '';
    
    alert(`Mood logged! Score: ${normalized}`);
    renderChart();
});

// Render chart on load
renderChart();
